# **[TdM ⿻ Client 〽️](https://www.youtube.com/watch?v=0KEX7KgKQ8A)**
**Somente um Crash Client para WhatsApp**

[![Vídeo "Trailer" do Client](https://cdn.discordapp.com/attachments/880068905819844638/884750352468021288/image0.png)](https://www.youtube.com/watch?v=0KEX7KgKQ8A&ab_channel=davizinmaker%CF%9F)
[Ensinando iniciar pelo PC clicando aqui](https://www.youtube.com/watch?v=Zlhhz7EybhQ)

> Discord para suporte [clicando aqui](https://discord.gg/z3e8B7WKt6).
> 
> Vídeo ensinando a instalar, baixar e usar [clicando aqui](https://www.youtube.com/watch?v=qpbCl9iPEXc)

# Motivo
O objetivo desse projeto é poder explorar falhas existentes no WhatsApp, deixando assim, publicas, para que os desenvolvedores resolvam, pois já tentei reportar elas e eles não deram a mínima. 

> Não me responsabilizo por mal uso do script e peço por favor para que não abusem dele.
# Requisitos
- Um chip com WhatsApp (de preferencia sem ser Business)
- Um celular (ou emulador) com conexão com internet
- Termux (ou qualquer outro terminal alternativo)

# Instale o BOT
```sh 
termux-setup-storage
```
```sh 
pkg install git && pkg install wget && pkg install ffmpeg && pkg install nodejs-lts && git clone https://github.com/davizinmaker/tdmclient/ && cd tdmclient && bash install.sh
```
# Para iniciar
```sh
> npm start
```
# Para ver os demais comandos use
```sh
> .help
ou
> .menu
```
## Equipe <3
> Criador do BOT - [davizinmaker](https://abre.ai/davizinmakerk/)

> Criador da API - [Baileys](https://github.com/adiwajshing/Baileys/)

> Criador da Base do BOT - [MhankBarBar](https://github.com/MhankBarBar/termux-wabot/)

> Quem fez o vídeo ensinando como instalar - [Travadores SC](https://www.youtube.com/channel/UCne7VGLOIddTRdReBhpvkJQ)

> Helper => Ligava o BOT pra eu testar quando meu PC não rodava emulador pra executar o Termux - [Japa 777](https://www.youtube.com/channel/UCxJHuL1YeMTJUE8I1qEjZmw)

> Ajudou no numero de tokens para testes - [Sulista (videos em breve)](https://youtube.com/channel/UCWHPxJlk6SsWQyqc0PnyCRw), [Cleitin](https://www.youtube.com/channel/UCRNJPQ_6U3LPlw4YzvoXePQ) e [Silverzin God](https://www.youtube.com/channel/UCMgdQnoTd00CMqwU3uNn9tg)
