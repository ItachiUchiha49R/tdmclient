#!discord.gg/tdmhouse

npm install discord-rpc
npm install

echo "[*] TODOS OS DEPENDENTES FORAM INSTALADOS COM SUCESSO !!"
